# Blockchain-in-MySQL
Blockchain is represented in form of tables<br>
source - https://benjaminsky.medium.com/blockchain-by-example-in-sql-server-8376b410128
