create table Transaction_type(
	transaction_type_id int primary key,
    transaction_type_desc varchar(30)
    );