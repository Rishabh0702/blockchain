create table user(
	user_id int primary key,
    full_name varchar(200)
    );