# Blockchain
Online voting system using Blockchain in C++
* SHA256 is used to create hash.
* Encryption and Decryption is done using RSA Algorithm.
* Digital signature is also added for authentication.
